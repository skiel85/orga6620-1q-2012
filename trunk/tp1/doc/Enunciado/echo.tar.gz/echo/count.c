#include <unistd.h>

#define stdinfd 	0
#define stdoutfd 	1

ssize_t my_read(int,void*,size_t);
ssize_t my_write(int,const void*,size_t);

/*
*	Lee un caracter desde stdin y lo escribe por stdout
*	hasta llegar al EOF
*
*/
int 
main(int argc,char **argv)
{

	char c;
	while (my_read(stdinfd,&c,1))
	{
		my_write(stdoutfd,&c,1);
	}
	
	return 0;
}
